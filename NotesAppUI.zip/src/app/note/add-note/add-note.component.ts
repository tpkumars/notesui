import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { INote } from 'src/app/model/note';
import { SharedService } from 'src/app/shared.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-note',
  templateUrl: './add-note.component.html',
  styleUrls: ['./add-note.component.css']
})
export class AddNoteComponent implements OnInit {

  id: number = 0;
  title: string = "";
  content: string = "";
  message: string = "";
  constructor(private service:SharedService, private router:Router) {
    console.log("In AddNote: constructor()");
   }

  ngOnInit(): void {
    console.log("In AddNote: ngOnInit()");
    let noteInfo = {
      id: 0,
      title:'',
      content:''
    }
  }

  addNote(formValue: NgForm){
    console.log("formValues: " +JSON.stringify(formValue.value));
    console.log("title: " +formValue.value.title);
    var val ={Title: formValue.value.title, NoteContent: formValue.value.content}
    this.service.addNote(val).subscribe(res =>{
      console.log(res);
      if(res!=null)
        this.message="Your note has been added sucessfully.";
      else
        this.message = "Failed to store your note."
    })
    this.gotoNotesList();
  }

  resetForm(formValue: NgForm){
    formValue.reset();
    this.message="";
  }

  closeForm(formValue: NgForm){
    this.resetForm(formValue);
  }

  gotoNotesList()
  {
    this.router.navigate(['/notes']);
  }

}
