import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-note',
  templateUrl: './delete-note.component.html',
  styleUrls: ['./delete-note.component.css']
})
export class DeleteNoteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
