import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewCompiler } from '@angular/compiler';
import { NoteComponent } from './note/note.component';

const routes: Routes = [
  {path:'', component: NoteComponent},
  {path:'notes', redirectTo:'', component:NoteComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {onSameUrlNavigation: "reload"})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
